<?php
require_once dirname( __FILE__ ) . '/class-tgm-plugin-activation.php';
require_once dirname( __FILE__ ) . '/admin/plugins.php';
require_once dirname( __FILE__ ) . '/admin/options.php';
require_once dirname( __FILE__ ) . '/admin/admin-fix.php';
require_once dirname( __FILE__ ) . '/admin/widgets.php';
?>